To compile and watch sass run: 

sass --watch src/scss/:css/
